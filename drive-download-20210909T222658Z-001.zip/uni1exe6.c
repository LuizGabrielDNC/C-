#include<stdio.h>
int main()
{
	int num1 , num2 ;
	printf("\n Digite o primeiro numero :: ");
	scanf("%d",&num1);
	printf("\n Digite o segundo numero :: ");
	scanf("%d",&num2);
	system("pause");
	printf("\n A soma � %d",num1+num2);
	return(0);
}
