#include <stdio.h>
#include <stdlib.h>
int main(){
	printf("Bom dia segue o comando do coteiner 1 para o 2");
	system("pause");
	printf("segue o comando y");
}

