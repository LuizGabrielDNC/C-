#include<stdio.h>
main()
{
	char nome[20];
	
	scanf("%s",nome);
	
	printf("\nBem vindo a disciplina de algoritmo %s",nome);
	return(0);
}
