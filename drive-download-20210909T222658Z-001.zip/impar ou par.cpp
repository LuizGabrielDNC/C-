#include <stdio.h>
#include <stdlib.h>
int main()
{
	int num, r;
	
	printf("Digite um numero : \n ");
	scanf("%d", &num);
	r= num /2;
	r= num - (r * 2);
	if(r ==0){
		printf("este numero e par ");
	}else
		printf("o numero e impar ");
	}

