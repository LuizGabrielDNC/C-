#include <stdio.h>
int main ()
{
	int	idade, ano;
	float altura;
	char  nome[30];
	printf ("Digite seu nome: ");
	scanf ("%s", nome);
	printf ("Digite a idade: ");
	scanf ("%d", &idade);
	printf ("Digite a altura: ");
	scanf ("%f", &altura);
	
	ano = 2020 - idade
	
	
	printf ("\nA idade � :%d",idade);
	printf ("\nO ano de nascimento e : %d",ano);
	return (0);
}
