#include <stdio.h>
int main()
{
	float valor, fmensal , fanual ;
	int qtade;
	
	printf("Informe a quantidade de carros : ");
	scanf("%d", &qtade);
	
	printf("\nInforme o valor da loca�ao : ");
	scanf("%f", &valor);
	fmensal = qtade * valor;
	fanual = ((qtade * 0.8)*valor)*12;
	
	printf("O faturamento mensal e %.2f o anual considerando 80 liquido e %.2f",fmensal,fanual);
	return(0);
	
}
