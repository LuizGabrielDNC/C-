#include <stdio.h>
int main()
{
	char nome[30];
	int i;
	 printf("iNFORME O NOME : \n");
	 scanf("%s", &nome);
	 i=0;
	 while(i !=10)
	 {
	 	printf("\n%d - %s", i, nome);
	 	i++;
	 }
}
