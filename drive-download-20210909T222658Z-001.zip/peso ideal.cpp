#include<stdio.h>
int main()
{
	float altura , peso;
	char sexo;
	printf("Informe o sexo (M/F): ");
	scanf("%c", &sexo );
	printf("Informe a altura: ");
	scanf("%f", &altura );
    
    if((sexo=='F') || (sexo =='f'))
    {
    	peso = (62.1 * altura)- 44.7;
    	
	}
	else
	{
		peso = (72.7 * altura) - 58;
	}
	printf("\nO sexo e :\n%c", sexo);
	printf("\nSeu peso ideal e : %.2f", peso);
	return(0);
}
