#include<stdio.h>
int calquadrado(int x);
int main()
{
	

   int num,res;
   printf("Digite um numero inteiro : ");
   scanf("%d",&num);
   res = calquadrado(num);
   printf("O quadrado do numero E%d e %d\n",num,res);
}
int calquadrado(int x)
{
	x = x*x;
	return x;
}
