#include <stdio.h>
int main()
{
	float preco , pdesconto , vdesconto , vpagar ;
	
	printf("Informe o preco do produto : ");
	scanf("%f", &preco);
	
	printf("\nInforme o percentual do desconto : ");
	scanf("%f", &pdesconto);
	
	vdesconto = (preco * pdesconto)/100;
	vpagar = preco - vdesconto;
	
	printf("\nO valor a pagar e : %.2f", vpagar);
	printf("\nO valor do desconto e : %.2f", vdesconto);
	return(0);
	
}
