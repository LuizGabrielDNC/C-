# include <stdio.h>
int main ()
{
		printf ("My name is Luiz Gabriel i am live in brazil  ");
		return (0);
}

