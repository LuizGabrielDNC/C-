#include <stdio.h>
#include <stdlib.h>
int main()
{
	float peso;
	float altura;
	float imc;
	
	printf("Insira o peso :\n");
	scanf("%f", &peso);
	printf("Insira a altura :\n");
	scanf("%f", &altura);
	
	imc = peso/(altura * altura);
	printf("Imc : %.2f\n", imc);
	
	if(imc < 21.0)
	{
		printf("Abaixo do peso \n ");
	}
	else
	{
		if(imc > 30.75)
		{
			printf("Acima do peso\n ");
		}
		else
		{
			printf("peso padrao \n");
		}
	}
}
