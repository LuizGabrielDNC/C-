#include <stdio.h>
int main()
{
	int vetorA[10];
	int i;
	
	for (i=0;i<=10;i++)
	{
		printf("Digite o %d elemento do vetor : \n",i);
		scanf("%d", &vetorA[i]);
	}
	printf("vetor preenchido \n");
	for(i=0;i<=10;i++)
	{
		printf("o elemento da posicao %d E :%d",i,vetorA[i]);
	}
}
