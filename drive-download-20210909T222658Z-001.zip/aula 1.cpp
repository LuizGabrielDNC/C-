#include <stdlib.h>
#include <stdio.h>
int main()
{
	printf("Ola mundo.\n ");
	system("pause");
	
	system("cls");
	system("pause");
}
