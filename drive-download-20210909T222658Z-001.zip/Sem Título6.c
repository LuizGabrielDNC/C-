#include <stdio.h>
int main()
{
	#define A 10
	int s, soma;
	
	printf("Digite sua idade :");
	scanf("%d", &s);
	soma=s-A;
	printf("A idade menos 10 � :%d", soma);
}
