#include<stdio.h>
#include<math.h>
int main()
{
	int a;
	
	printf("Bem vindo a wesd , digite a senha :: \n");
	scanf("%d", &a);
	fflush(stdin);
	if(a == 5236)
	{
		printf("SA. 289289 >-- 1290930920");
	}
	else
	{
		printf("Senha incorreta mais 2 erros conta toma bloq");
	}
	return(0);
}
