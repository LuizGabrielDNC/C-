#include <stdio.h>
#include <stdlib.h>
int main ()
{
	float vhora,naulas,pdesconto,sliquido ,sbruto;
	
	
	printf("Informe o valor da hora - aula : ");
	scanf("%f", &vhora);
	
	printf("\nInforme o numero de hora aula dada no mes : ");
	scanf("%f", &naulas);
	
	printf("\n Informe o percentual de desconto do inss : ");
	scanf("%f", &pdesconto);
	
	system("pause");
	system("cls");
	
	
	
	sbruto = vhora * naulas;
	sliquido = sbruto -(sbruto * pdesconto)/100;
	
	printf("\nO valor do salario bruto e :%.2f ", sbruto);
	printf("\nO valor do salario liquido e :%.2f ", sliquido);
	return (0);
}
