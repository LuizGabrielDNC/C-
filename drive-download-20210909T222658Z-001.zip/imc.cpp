#include <stdio.h>
#include <stdlib.h>

int main()
{
	float	peso, altura, imc;
	char	op;
	
	do{
	
		printf	("Insira o peso :\n");
		scanf	("%f", &peso);
	
		printf	("Insira sua altura : \n");
		scanf	("%f", &altura);
	
		imc = peso/(altura * altura);
	
		printf	("imc :%.2f\n", imc);
	
		if	(imc < 21.0)
		{
		printf	("Abaixo do peso \n");
		}
		else
		{
		
			if	(imc > 30.75)
			{
		
			printf("OBESO .\n");
			}
			else{
				printf	("Peso padrao .\n");
			}
		}
		printf	("DEseja eecutar novamente ? (y/n)\n");
		scanf	("%c", &op);
		system ("cls");
	}while(op == 'y' || op == 'Y');
}




	

