#include <stdio.h>
#include <stdlib.h>
int main(){
	int a;
	printf("Digite a senha : \n");
	scanf("%d", &a);
	if(a==121)
	{
		printf("bom dia \nSua conta possui em R$ 900,00");
		
		
	}
	else
	{
		printf("Senha invalida ou incorreta");
	}
}
