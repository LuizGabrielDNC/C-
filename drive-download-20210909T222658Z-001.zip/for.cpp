#include <stdio.h>
int main(){
	int num, contador;
	for(contador=1;contador<=100;contador ++)
	{
		printf("%d\n", contador);
	}
}
