#include <stdio.h>
#include <stdlib.h>
int main(){
	float	numero;
	printf("Digite um numero inteiro :\n");
	scanf("%f", &numero);
	if(numero > 10 || numero == 0){
		printf("O numero e maior que 10 ou e 0. \n");
	}
	
}
