#include <stdio.h>
#include <stdlib.h>
int main()
{
	int cont;
	for(cont=0; cont<10; cont++)
	{
		printf("%d", cont);
	}
}
