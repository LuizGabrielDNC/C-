#include <stdio.h>
#include<stdlib.h>
int main()
{
	int soma=0,valor;
	
	while(soma<100)
	{
		printf("\nDigite um numero : \n");
		scanf("%d", &valor);
		soma = soma + valor ;
		printf("\nO VALOR TOTAL E :\n %d",soma);
	}
	
}
