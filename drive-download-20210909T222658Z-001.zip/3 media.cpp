#include <stdio.h>

int main()
{
	float	num1, num2, num3, num4, media;
	
	printf	(" \nInforme o primeiro nota :");
	scanf	("%f", &num1);
	
	printf	("\n Informe a segunda nota :");
	scanf	("%f", &num2);
	
	printf	("\n Terceira nota :");
	scanf	("%f", &num3);
	
	printf	("\n Quarta nota : ");
	scanf	("%f", &num4);
	
	media = (num1+num2+num3+num4)/4;
	
	printf	("\n a media e: %.2f\n", media);
}
	


	
	


	

