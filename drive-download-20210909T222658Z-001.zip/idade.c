#include <stdio.h>
int main(){
	int idade;
	printf("Digite a idade :");
	scanf("%d", &idade);
	print(" A sua idade � : %d",idade);
}
