#include <stdio.h>
 main()
{
	printf("hELLO WORLD");/* mostrar mensagem ao user.*/
}
