#include <stdio.h>
#include <locale.h>
#include <math.h>
int main()
{
	setlocale(LC_ALL, "Portuguese");
	int num;
	float raiz;
	
	printf("Digite um numero interiro :");
	scanf("%d", &num);
	if (num % 2 ==0)
	{
		raiz = sqrt(num);
		printf("\n a raiz quadrada e : %.3f", raiz);
	}
}
