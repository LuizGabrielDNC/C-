#include <stdio.h>
int main()
{
	int idade, ano;
	float altura;
	char nome[30];

	printf("digite seu nome ");
	scanf("%s", nome);
	
	printf("Digite a idade :");
	scanf("%d", idade);
	
	printf("Digite sua altura:");	

}
