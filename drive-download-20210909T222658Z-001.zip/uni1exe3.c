#include<stdio.h>
#include<math.h>
main()
{
	int valor;
	
	printf("Digite um numero inteiro :: ");
	scanf("%d",&valor);
	printf("\nA potencia de %d e %.2f ",valor,pow(valor,2));
	printf("\nA raiz de %d e %.2f ",valor,sqrt(valor));
	
	
	
}
