#include <stdio.h>
int main()
{
	float num1, num2, resultado;
	int op;
	
	printf("DIgite o primeiro numero : \n");
	scanf("%f", &num1);
	printf("Digite o segundo numero : \n ");
	scanf("%f", &num2);
	printf("Escolha a operacao : \n 1 - soma \n 2 - divisao \n 3- subtracao \n 4 - multiplicacao \n");
	scanf("%d", &op);
	if()
