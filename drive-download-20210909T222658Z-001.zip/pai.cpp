#include <stdio.h>
int main()
{
	printf("melhor pai do mundo luiz chaves");
}
