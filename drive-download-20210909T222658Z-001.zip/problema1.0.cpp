#include <stdio.h>
int main()
{
	int num;
	
	printf("Digite o numero : ");
	scanf("%d", &num);//leitura de um numero inteiro percento d

	
	printf("\nO antecessor e : %d", num-1);//no printf o uso  de operacoes � permetido
	printf("\nO sucessor e  : %d", num +1);
	return(0);
}
