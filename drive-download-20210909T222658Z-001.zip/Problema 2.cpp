#include <stdio.h>
int main()
{
	float n1 , n2, n3, n4, media;//Var float
	
	printf("\nDigite a nota 1 :");
	scanf("%f", &n1);//leitura de numero float
	printf("\nDigite a nota 2 :");
    scanf("%f", &n2);
    printf("\nDigite a nota 3:");
    scanf("%f", &n3);
    printf("\nDigite a nota 4 :");
    scanf("%f", &n4);
    media = (n1+n2+n3+n4)/4;
    printf("\nA media do aluno e : %.2f\n", media);//2 ponto depois do float
    return(0);
    
}
