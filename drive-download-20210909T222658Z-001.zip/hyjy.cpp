#include<stdio.h>
int main()
{
	char frase [30];
	int i,numero;
	printf("Digite a frase : \n");
	gets(frase);
	printf("Digite o numero de repeticoes : \n");
	scanf("%d", &numero);
	for(i=1;i<=numero ;i++)
	{
		printf("%s\n",frase);
	}
}
