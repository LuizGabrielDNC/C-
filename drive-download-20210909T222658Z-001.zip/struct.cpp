#include<stdio.h>
struct produto
{
	int codigo;
	char descricao[50];
	float preco;
	int saldo;
};
int main()
{
	struct produto ficha;
	printf("Digite o codigo do produto : ");
	scanf("%d",&ficha.codigo);
	printf("digite a descricao do produto  :");
	scanf("%s",ficha.descricao);
	printf("Digitee o preco do produto : ");
	scanf("%f",&ficha.preco);
	printf("digite o saldo do produto : ");
	scanf("%d",&ficha.saldo);
	
	
	printf("Codigo : %d\n",ficha.codigo);
	printf("descricao : %s\n",ficha.descricao);
	printf("preco :%.2f\n",ficha.preco);
	printf("saldo : %d\n",ficha.saldo);
}
