#include <stdio.h>
#include <stdlib.h>
int main (){
	int idade;
	printf("Digite a idade : \n");
	scanf("%d", &idade);
	printf("A idade digitada foi = %d", idade);
}
