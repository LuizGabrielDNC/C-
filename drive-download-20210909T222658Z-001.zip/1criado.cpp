#include <stdio.h>
int main(){
	int idade;
	printf("digite sua idade : ");
	scanf("%d", &idade);
	if(idade<18)
	{
	
		printf("NAo pode consumir bebiba alcolica");
    }
    else
    {
    	printf("Bebida pode ser comprada ..");
	}
}
