#include<stdio.h>
int main()
{
	float soma;
	int i;
	for(i=200;i<=500;i++)
	{
	if(i%3==0)
	   printf("O numero %d e divisivel por 3\n",i);
	if(i%7==0)
	   printf("O numero %d e divisivelpor 7\n",i);
	}
}
