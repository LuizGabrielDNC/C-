#include <stdio.h>

int main ()
{
	char nome[20];
	
	printf	("Qual e seu nome :");
	scanf	("%s", nome);
	
	printf	("\n Bem vinda a disciplina alp 2 %s", nome);
	return (0);
}
