#include <stdio.h>
 int main(void) {
    int x= 17, y=2;
 	float z;
	 z = x / y;
  	printf ("%d / %d = %.2f\n", x,y,z);
  	return (0);
 }
