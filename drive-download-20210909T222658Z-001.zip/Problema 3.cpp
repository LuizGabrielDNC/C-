#include <stdio.h>
int main()
{
	float deposito , taxa , rendimento , total;
	
	printf("Informe o valor depositado  ");
	scanf("%f", &deposito);
	
	printf("\nInforme a txa de juros : ");
	scanf("%f", &taxa );
	
	rendimento = deposito * (taxa/100);//Processamento
	total = deposito + rendimento;
	
	printf("\nO rendimento e :%.2f", rendimento);
	printf("\nO total estabelecido e :%.2f", total);
	return(0);
}
