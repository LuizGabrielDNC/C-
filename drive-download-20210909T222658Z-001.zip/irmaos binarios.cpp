#include<stdio.h>
int main()
{
	int vetor[10];
	int i,acha,busca;
	for(i=0;i<10;i++)
	{
		printf("Digite %d elemento : ",i);
		scanf("%d", &vetor[i]);
	}
	printf("Informe o elemento que deseja buscar : ");
	scanf("%d",&busca);
	i=0;
	acha=0;
	while((acha ==0) && (i<10))
	{
		if(vetor[i ]== busca)
		{
			acha =1;
		}
		else
		{
			i++;
		}
	}
	if(acha== 1)
	printf("O elemneto %d foi encontrado na posica %d ",busca,i);
	else
	printf("O elemento nao foi encontrado ");
}
