//Comentario sobre o app em c
//
#include<stdio.h>
int main()
{
	printf("Hello, world");
	
	
}
