#include<stdio.h>
int main()
{
	int vetorA[10];
	int i;
	
	for (i=0;i<10;i++)
	{
		printf("Digite o %d elemento do vetor : \n",i);
		scanf("%d", &vetorA[i]);
	}
	for (i=0;i<10;i++)
	{
		printf("O elemnto da posicao %d e: %d",i,vetorA[i]);
		
	}
}
