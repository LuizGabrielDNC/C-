#include <stdio.h>
#include<stdlib.h>
struct produto 
{
	int codigo;
	char descricao[70];
	float preco;
	int saldo;
};
int main()
{
	struct produto ficha[10];
	int i;
	
	for (i=0;i<10;i++)
	{
	printf("Digite o codigo do produto : ");
	scanf("%d",&ficha[i].codigo);
	printf("digite a descricao do produto  :");
	scanf("%s",ficha[i].descricao);
	printf("Digitee o preco do produto : ");
	scanf("%f",&ficha[i].preco);
	printf("digite o saldo do produto : ");
	scanf("%d",&ficha[i].saldo);
	system ("cls");
	}
	for (i=0;i<10;i++)
	{
		printf("\nPRODUTO %d\n",i+1);
		printf("Codigo :%d\n",ficha[i].codigo);
		printf("descricao : %s\n",ficha[i].descricao);
		printf("preco %.2f",ficha[i].preco);
		printf("saldo :%d\n",ficha[i].saldo);
	}
	
}


	
 
