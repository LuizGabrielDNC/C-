#include<stdio.h>
int main()
{
	int idade,ano;
	float altura;
	char nome[30];
	/*declaracao de variaveis*/
	
	printf("Digite seu nome : ");
	scanf("%s",nome);
	
	printf("Digite a idade : ");
	scanf("%d",&idade);
	
	printf("Digite a altura : ");
	scanf("%f",&altura);
	
	/* Processamento do ano de nascimento*/
	ano = 2021 - idade;
	
	printf("\nO nome e : %s",nome);
	printf("\nA altura :%.2f  idade :%d   ano de nascimento :%d ",altura,idade,ano); 
	
}


